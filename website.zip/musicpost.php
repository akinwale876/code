

<!DOCTYPE html>

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php 


include $_SERVER['DOCUMENT_ROOT'] . '/postdata3.php';


?>

 <title>DOWNLOAD  <?php echo $title ;?> - Naijaramz Music</title>

<meta name="title" content="Download: <?php echo $description;?>"/>


<?php 

$category ='music';

include 'cookie.php';


?>

<meta name="description" content="Download <?php echo substr($content, 0, 30)?>"/>

<meta property="og:title" content="<?php echo $title;?>"/>

<meta property="og:image" content="<?php echo $image; ?>">

<meta property="og:description" content="<?php echo $description;?>" />
		
<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="canonical" href="<?php echo 'http://naijaramz.com/music/'. $cleanurl;?>" />
<meta property="og:site_name" content="Naijaramz" />
<meta property="og:url" content="<?php echo 'http://naijaramz.com/music/'. $cleanurl;?>" />
<meta property="twitter:image" content="<?php echo $image;?>"/>
<meta property="og:image:width" content="1296" />
<meta property="og:image:height" content="729" />
<meta property="og:type" content="article" />
<!-- Indicate preferred brand name for Google to display -->


<?php


include $_SERVER['DOCUMENT_ROOT'] . '/head.php';


?>



<style>
    
    @import 'https://fonts.googleapis.com/css?family=Lato';


body {
	font-family: 'Lato';
	
	
}


article{
	width: 90%;
	height: 440px;
	top: 40px;
	left: 0;
	bottom: 0;
	right: 0;
	margin: auto;
	text-align: center;
	padding: 50px 5%;
	box-sizing: border-box;
	box-shadow: 0 0 11px 0px rgba(0,0,0,0.3);
	border-radius: 10px;
}

.contt{
	margin-bottom: 28px;
}

.contt h3{
	font-family: 'Lato';
	font-size: 40px;
	margin: 0 0 10px 0;
	color: #ccc;
}

.contt h4{
	font-family: 'Lato';
	font-size: 20px;
	margin: 0 0 10px 0;
	color: #ccc;
}

.contt time{
	font-family: 'Lato';
	font-size: 12px;
	color: #999;
	
}

    
</style>
</head>
<body>


<?php



include $_SERVER['DOCUMENT_ROOT'] . '/header.php';



?>


    <h6 style="display:inline-block;margin:3px;margin:15px;padding:15px;"><?php echo '<a style="" href="http://'. $_SERVER["SERVER_NAME"] .'">Home</a>' .' / <a href="https://'. $_SERVER["SERVER_NAME"]. '/Music">Music</a> / ' . $cleanurl .'</span>';?></h6>



<span onclick="addCom()" style="float:right;font-family:Lato;font-size:10px;margin-top:15px;margin-right:10px;cursor:pointer;"><i class="fa fa-comment"></i>Click here to add comment</span>




<h1 class="post-h1">Download: <?php echo ucfirst($title);?> </h1>


<div class="wrapper">

<div class="main" style="background:white;color:black;">

    
<a href="#comment"><h6 style="display:inline-block;padding-top:2px;padding:3px;"><i class="fa fa-comment"></i><span style="color:red;margin-left:3px;background:white;padding:4px;display:inline-block;">
    comments <?php 
$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$comment_id'");


$num_post_query = mysqli_num_rows($comment_post_query);

 echo $num_post_query;?></span></h6></a>
    
    
<h6 style="display:inline-block;padding-top:2px;padding:3px;"><i class="fa fa-eye"></i><span style="color:black;margin-left:3px;background:white;padding:4px;display:inline-block;">
    views <?php echo $views;?></span></h6>



    <?php  
    
    echo '<h6 style="font-size:12px;color:brown;margin-left:2px;color:black;display:inline-block;padding-top:2px;padding:6px;">Posted by  <span style="color:brown;">'.$author . '</span></h6>';
    
    ?>
    
    <span style="font-size:12px;font-weight: 700;padding-top:4px;padding-bottom:4px;"><?php echo '<i class="fa fa-clock"></i><span style="margin-left:8px;">' . $date .'</span>'?> </span>




<center>
<div style="width:95%;color:rgb(100,100,100);padding: 6px;">
	



<img src="<?php echo str_replace('http','https',$image); ?>"  width="99%" style="height:auto;"  />



</div>

</center>

<div >
    
    
<h2 style="font-family:Arial;margin-bottom:60px;color:rgb(80,80,100);">


<?php 
echo  $description;
?>


</h2>
    
</div>


</p>

<div class="p-content" style="margin-top:50px;">

<?php 
echo '
Download '.$title.'.';


?>


<?php 
echo $content;
?>
<br>


<br>


    
</div>



<br>
<center>
		<h3>
    
<?php 
echo 'Play '. $title;
?>
</h3>
		<time>
    
<?php 
echo $date;
?>
</time>
<br>
<br>
	<audio class="audio"  style="width:90%;"  controls="controls">
		<source type="audio/mpeg" src="<?php echo str_replace('http','https',$video_id);?>">
	</audio>





<br>
<br>
<br>
    
    
    
</center>

<br>



<br>
<center>
	

	<a  style="font-size:11px;border-radius:10%;padding:8px;border:1px solid rgb(200,20,20);color:rgb(200,20,20);" href="<?php echo $video_id;?>"  download> Download Mp3</a>
</center>

<br>



<br>


<p>Share this music to any of the social media platform</p>

<?php

include $_SERVER['DOCUMENT_ROOT'] .'/sharer.php';

?>


<br>

<br>

<h4>You May Like</h4>

<?php



$post_queryt = mysqli_query($conn,"SELECT * FROM music  ORDER BY id DESC LIMIT 3");


while($datat = mysqli_fetch_array($post_queryt)){
    


$titlet = $datat['title'];
$descriptiont= substr($datat['description'],0,60);

$cleanurlt = $datat['cleanurl'];
$pic= $datat['picture_url'];

$date = $datat['date'];

$date = date('   l d-M-Y', $date);


echo   '<a style="text-decoration:none;"  href="http://'.$_SERVER["SERVER_NAME"] .'/music/'. $cleanurlt .'">
<div class="post">


<img src="'. str_replace('http','https',$pic).'" class="img">
<div class="post-title">
<h4>

'.$titlet .'</h4>


<p style="font-size:11px;color:rgb(250,110,110);">'.$descriptiont.'</p>
</div>


</div></a>';








}





?>

<br>

<?php

$relate_post_query = mysqli_query($conn,"SELECT * FROM music WHERE tag='$tag'  AND id !='$id' ORDER BY id DESC LIMIT 4 ");


if(mysqli_num_rows($relate_post_query) > 0){
echo '
<article style="height:auto;"><h4> More of '.$tag.'</h4>' ;


}




while($movi = mysqli_fetch_array($relate_post_query)){

$rlist_title = $movi['title'];
$rlist_cleanurl = $movi['cleanurl'];
$rlist_image = $movi['picture_url'];
$rlist_date = date('l m:ha d-M-Y',$movi['date']);




echo   '
<a style="text-decoration:none;" href="http://'.$_SERVER["SERVER_NAME"].'/music/'. $rlist_cleanurl.'">
<h3>'.$rlist_title .'</h3>
</a>';






}


if(mysqli_num_rows($relate_post_query) > 0){
echo '
</article>' ;


}




include  $_SERVER['DOCUMENT_ROOT'] .'/comment.php';





?>
</div>



<!--     ending of main-->

<?php




include $_SERVER['DOCUMENT_ROOT'] . '/sidebar.php';



?>



</div>


</div>


<?php




include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';



?>


<script>
    
    function addCom(){
        
        var x = document.getElementById('comment');
        
        
        
        x.focus();
        
        
    }
    
    
</script>



</body>

</html>