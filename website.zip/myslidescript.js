
function __(el){

	return document.getElementsByClassName(el);
}



var slideElements = __('slide-post');

slideElements[0].style.display= 'block';


count = 1;

function slide(num) {
	



count += num;




if(count > slideElements.length){

	count = 1;
}




for (var i = 0; i < slideElements.length; i++) {
	slideElements[i].style.display = 'none';
}






slideElements[count - 1].style.display= 'block';


}


setInterval(function(){slide(1)},6200);
















var separateslideElements = __('separate-slide-post');

separateslideElements[0].style.display= 'block';


separatecount = 1;

function separateslide(num) {
	



separatecount += num;




if(separatecount > separateslideElements.length){

	separatecount = 1;
}




for (var i = 0; i < separateslideElements.length; i++) {
	separateslideElements[i].style.display = 'none';
}






separateslideElements[separatecount - 1].style.display= 'block';


}


setInterval(function(){separateslide(1)},6200);

