

<!DOCTYPE html>

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php 


include $_SERVER['DOCUMENT_ROOT'] . '/postdata2.php';


?>

 <title>DOWNLOAD <?php echo str_replace('– Latest Nollywood','',$title) ;?> - Naija Ramz Movie</title>

<meta name="title" content="Download: <?php echo $title;?>"/>



<?php


include 'cookie.php';
?>

<meta name="description" content="Download <?php echo $title .' '. substr($content, 0, 30)?>"/>

<meta property="og:title" content="<?php echo $title;?>"/>

<meta property="og:image" content="<?php echo $image; ?>">

<meta property="og:description" content="<?php echo $description;?>" />
		
<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="canonical" href="<?php echo 'http://naijaramz.com/movie/'. $cleanurl;?>" />
<meta name="description" content="<?php echo $description  . '. ' . substr($content,0,130) ;?>" />
<meta property="og:site_name" content="naijaramz.com" />
<meta property="og:url" content="<?php echo 'http://naijaramz.com/movie/'. $cleanurl;?>" />
<meta property="twitter:image" content="<?php echo $image;?>"/>
<meta property="og:image:width" content="1296" />
<meta property="og:image:height" content="729" />
<meta property="og:type" content="article" />
<meta name="twitter:site" content="Naija Ramz" />
<meta name="title" content="<?php echo $title;?>"/>
<meta name="medium" content="article" />
<!-- Indicate preferred brand name for Google to display -->


<?php


include $_SERVER['DOCUMENT_ROOT'] . '/head.php';


?>

<body>


<?php



include $_SERVER['DOCUMENT_ROOT'] . '/header.php';



?>
    <h6 style="display:inline-block;margin:3px;margin:15px;padding:15px;"><?php echo '<a style="" href="http://'. $_SERVER["SERVER_NAME"] .'">Home</a>' .' / <a href="http://'. $_SERVER["SERVER_NAME"]. '/'.$category .'">' . $category .'</a> / ' . $cleanurl .'</span>';?></h6>



<span onclick="addCom()" style="float:right;font-family:Lato;font-size:10px;margin-top:15px;margin-right:10px;cursor:pointer;"><i class="fa fa-comment"></i>Click here to add comment</span>



<h1 class="post-h1" >DOWNLOAD: <?php echo $title;?> </h1>


<div class="wrapper">
    
    
    
<div class="main" style="background:white;color:black;">

<h6 style="margin-top:2px;color:black;display:inline-block;padding-top:2px;padding:6px;font-weight:bold;">Category :<span style="color:black;margin-left:3px;background:white;padding:2px;display:inline-block;">
    <?php echo $category;?></span></h6>
    
<a href="#comment"><h6 style="display:inline-block;padding-top:2px;padding:3px;"><i class="fa fa-comment"></i><span style="color:red;margin-left:3px;background:white;padding:4px;display:inline-block;">
    comments <?php 
$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$comment_id'");


$num_post_query = mysqli_num_rows($comment_post_query);

 echo $num_post_query;?></span></h6></a>
    
    
<h6 style="display:inline-block;padding-top:2px;padding:3px;"><i class="fa fa-eye"></i><span style="color:black;margin-left:3px;background:white;padding:4px;display:inline-block;">
    views <?php echo $views;?></span></h6>



    <?php  
    
    echo '<h6 style="font-size:12px;color:brown;margin-left:2px;color:black;display:inline-block;padding-top:2px;padding:6px;">Posted by  <span style="color:brown;">'.$author . '</span></h6>';
    
    ?>
    
    <span style="font-size:12px;font-weight: 700;padding-top:4px;padding-bottom:4px;"><?php echo '<i class="fa fa-clock"></i><span style="margin-left:8px;">' . date("l d-M-Y",$date) .'</span>'?> </span>



<center>
<div style>
	
<article style="height:auto;padding:6px;">
    
    
    <!--  -->
    
    
    
    <?php
    
    
    /*
<img style="border-radius:0px 4px 4px 0px;" src="https://i.ytimg.com/vi/<?php echo $video_id; ?>/hqdefault.jpg" 
alt="This movie is available for download dont mind the image not showing" width="100%" height="auto"  />
  
    */
    
    ?>

<img style="border-radius:0px 4px 4px 0px;" src="<?php echo str_replace('http','https',$image);?>" 
alt="This movie is available for download dont mind the image not showing" width="100%" height="auto"  />

    
</article>



</div>

</center>

<p >

</p>


<div class="p-content" style="color:gray;margin-top:50px;">

<p>
<?php 
echo '
Download ' . str_replace('– Latest Nollywood','',$title);


?>





<i><small><?php 
echo  'Featured by '.$tag. ' <a href="#related"> See more list</a>';
?></small></i>


</p>
<p>

        <p style="color:rgb(100,100,100);"><em>
<?php 
echo $content;
?></em></p>
</p>
<br>


<p style="font-size:13px;">Share this movie to any of the social media platform</p>

<?php

include $_SERVER['DOCUMENT_ROOT'] .'/sharer.php';

?>
<br>


    
</div>



<br>


<br>


<center>
	
	
	<?php
	
	if(strlen($video_id) > 11){

	  echo '
	<a style="font-size:11px;border-radius:10%;padding:8px;border:1px solid rgb(200,20,20);color:rgb(200,20,20);" 
	href="'. $video_id .'"> Download Here</a>';  
	    

	}else{
	  echo '
	<a style="font-size:11px;border-radius:10%;padding:8px;border:1px solid rgb(200,20,20);color:rgb(200,20,20);" 
	href="http://naijaramz.com/getvideoinfo.php?video_id='. $video_id .'&title='. $title.'"> Download Here</a>';  
	    
	}
	
	
	
	?>




</center>

<br>


<?php



$post_queryt = mysqli_query($conn,"SELECT * FROM movies WHERE tag='$tag'  AND id !='$id' ORDER BY id DESC LIMIT 3 ");


if(mysqli_num_rows($post_queryt) > 0){
    
    
echo '<a name="related"></a><h4  style="padding: 8px;color:black;">More of '.$tag.' <span style="text-indent: 10px;"><i class="fa fa-book"></i></span></h4>' ;


}


while($datat = mysqli_fetch_array($post_queryt)){
    


$titlet = $datat['title'];
$descriptiont= substr($datat['description'],0,60);

$cleanurlt = $datat['cleanurl'];
$pic= $datat['picture_url'];

$date = $datat['date'];

$date = date(' d-M-Y', $date);


echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/movie/'.$cleanurlt.'">

<div class="post" style="position:relative;">

<img alt="'.$list_title.'" class="img" src="'. str_replace('http','https',$pic). '">


<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($titlet).'</h4>
<br>
<small>'. $date .'</small>
</div>


    
</div></a>';







}




if(mysqli_num_rows($post_queryt) > 0){
  


}
?>

<?php


include  $_SERVER['DOCUMENT_ROOT'] .'/comment.php';





?>
</div>



<!--     ending of main-->

<?php




include $_SERVER['DOCUMENT_ROOT'] . '/sidebar.php';



?>



</div>


<?php




include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';



?>


<script>
    
    function addCom(){
        
        var x = document.getElementById('comment');
        
        
        
        x.focus();
        
        
    }
    
    
</script>


</body>

</html>