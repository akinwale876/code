<?php


require 'connection.php';



if (isset($_GET['url'])){

$url = $_GET['url'];


$post_query = mysqli_query($conn,"SELECT * FROM movies WHERE `cleanurl` ='$url'");


$data = mysqli_fetch_array($post_query);


$title = $data['title'];

$id = $data['id'];

$tag = $data['tag'];

$author = $data['author'];


$description= $data['full_title'];

$image = $data['picture_url'];

$cleanurl = $data['cleanurl'];
$video_id = $data['video_id'];

$content = $data['short_story'];
$category = $data['category'];

$comments = $data['comments'];
$comment_id = $data['comment_id'];
$views = $data['views'];

$downloads = $data['downloads'];

$date = $data['date'];






if(isset($_COOKIE[$title])){
    
    
}
else{
    
    

setcookie($title,$content,time() + (8600 * 30) , "/");


$conn->query("UPDATE movies SET `views` =`views` +1 WHERE id=$id");

}



}









?>