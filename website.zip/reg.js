
var firstname,lastname,email,password,confirm,data;

// preparing variables 

function _(el){

return document.getElementById(el);


}




// ..beginning of form validation...
function register(){




firstname = _('firstname');
lastname =_('lastname');
email = _('email');

 password = _('password');
confirm = _('confirm');


var formdata = new FormData();

formdata.append('firstname', firstname.value);
formdata.append('lastname', lastname.value);
formdata.append('email', email.value);
formdata.append('password', password.value);
formdata.append('confirm', confirm.value);

var ajax = new XMLHttpRequest();

ajax.upload.addEventListener('progress', progressHandle, false);
ajax.addEventListener('load', completeHandle, false);
ajax.addEventListener('error', errorHandle, false);
ajax.addEventListener('abort', abortHandle, false);
ajax.open("POST", "register_server.php");
ajax.send(formdata);



}


function progressHandle(event){

    _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

var percent = (event.loaded / event.total) * 100;

_('progressbar').value = Math.round(percent);
_('status').innerHTML = Math.round(percent) + "% upload... please wait";


}

function completeHandle(event){

_('status').innerHTML = event.target.responseText;

_('progressbar').value = 0;

}

function errorHandle(event){

_('status').innerHTML = "upload failed";



}

function abortHandle(event){

_('status').innerHTML = "upload aborted";



}




