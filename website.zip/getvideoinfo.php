


<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title><?php echo $_GET['title']; ?>  -  NaijaRamz Video Downloder</title>
	

<?php 

include 'head.php';


$video_id = $_GET['video_id'];

?>

</head>
<body style="background:white;color:black;">
    

<?php



include 'header.php';



?>



<div class="wrapper" style="min-height:auto;">
        <h2>List Of Available Formats</h2>
    <center>
        <h3>Download: <?php echo $_GET['title']; ?></h3>


      <img height="210px" src="https://i.ytimg.com/vi/<?php echo $video_id; ?>/hqdefault.jpg"><br><b><h3></b>

        <?php



if(isset($_GET['video_id'])){



$link = 'https://www.youtube.com/get_video_info?video_id='.$video_id . '&asv=3';


$curl_init = curl_init();

curl_setopt($curl_init, CURLOPT_URL, $link);
curl_setopt($curl_init, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl_init, CURLOPT_SSL_VERIFYPEER, 1);

 $result  = curl_exec($curl_init);



parse_str($result, $videosource);


 $videoinfo = json_decode(json_encode($videosource));




$arr = $videoinfo->player_response;




}


?>
       
       <br>
       <p>page download not available use this server below</p>
       
       <a href="https://www.y2mate.com/youtube/<?php echo $video_id;?>&type=Download">Download from y2mate Server</a>
   </center> 
   
   <p style="font-size:11px;">
       
       
       Note that the only way you can initiate download is by clicking video/format link.


<p style="font-size:13px;">kindly refresh this page if u get any error This Is Just A Youtube Downloader Website Our Content/Images/and More posted are believed to be published according to the Nigeria Copyright Fair Use Act.
<p style="font-size:11px;">
Every Movies We Put On This Platform Is Hosted On Popular Youtube Channels Which Will Be Removed Anytime The Movies Is Removed From The Youtube Channel Example of Youtube Channels Include: 1. 
 
    </div>
    
    
    
    

<?php




include 'footer.php';



?>

    
    

</body>
</html>
