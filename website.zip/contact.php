<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Contact Us - NaijaRamz </title>
<meta name="discription"
content="Contact - NaijaRamz" />

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>

<div class="wrapper">


 <div class="main">
     
     

        <br> 
<h1>Contact Us</h1>
<br>
        
      <center>  <img height="150px"  src="http://naijaramz.com/14763d33-d8f5-4a53-b4f8-10263d9de8b3_200x200.jpg" /></center>
       <br> <br>


	<form action="contact_server.php"   method="post">

    
    <div class="input-container">
    	



<input type="text" id="name" name="name" placeholder="Your Name"/>

    </div>

    
    <div class="input-container">
    	

<input type="text" id="email" name="email" placeholder="Email"/>



    </div>

		<br>
    
    	

<textarea id="message" name="message" placeholder="Message......" style="width:90%;min-height: 190px;">
</textarea>
    


		<br>
    
    
    <div class="input-container">
    	


<input type="submit" onclick="sendM()"  value="Send..!">


    </div>



	


	</form>

<div id="xdd"></div>

<script>



var name = document.getElementById('name');



var email = document.getElementById('email');



var message = document.getElementById('message');



var xdd = document.getElementById('x');



   function sendM() {
  


xdd.innerHTML ="ss...";

var formdata = new FormData();


formdata.append('name',name.value);

formdata.append('email',email.value);

formdata.append('message',message.value);



if (window.XMLHttpRequest) {
    // code for modern browsers
   var aja = new XMLHttpRequest();
 } else {
    // code for old IE browsers
   var aja = new ActiveXObject("Microsoft.XMLHTTP");
}




aja.upload.addEventListener('progress', progressHandl, false);
aja.addEventListener('load', completeHandl, false);
aja.addEventListener('error', errorHandl, false);
aja.addEventListener('abort', abortHandl, false);
aja.open("POST", "contact_server.php");
aja.send(formdata);



   	}




function progressHandl(event){

   // _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

//var percent = (event.loaded / event.total) * 100;

//_('status').innerHTML = Math.round(percent) + "% upload... please wait";
x.innerHTML = event.target.responseText;


}

function completeHandl(event){

x.innerHTML = event.target.responseText;


}

function errorHandl(event){

x.innerHTML = "upload failed";



}

function abortHandle(event){

x.innerHTML = "upload aborted";



}
	








</script>





  </div>



<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>


</body>
</html>