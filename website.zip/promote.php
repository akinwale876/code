<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Contact Us - NaijaRamz </title>
<meta name="discription"
content="Promote With Us - NaijaRamz" />

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>

<div class="wrapper">


 <div class="main" style="color:black;">
     
     

        <br> 
<h1>Promote With Us</h1>
<br>
        
      <center><a href="mailto:promote@naijaramz.com?Subject=Hello%20i%20want%20to%20promote%20my%20business" target="_top">Send us Mail</a></center>
       




  </div>



<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>


</body>
</html>