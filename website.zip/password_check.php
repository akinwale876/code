<?php
require 'connection.php';




if(isset($_POST['password'])){

    
   $password = $_POST['password'];
    
    $password = md5($password);

if($conn){
    

$sql = "SELECT * FROM author WHERE password='$password' LIMIT 1";

$query = mysqli_query($conn,$sql);


if(mysqli_num_rows($query) > 0){
    
    
    echo 'OK';
 
}else{
    
    
    echo 'OFF';
}


  
}
    
    
}




?>