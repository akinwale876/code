

    <nav><ul class="ul-list" style="background:rgb(40,40,40);color:white;">

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/about" >About Us</a>

        </li>
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/contact" >Contact Us</a>

        </li>
   
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/privacy-policy" >Privacy Policy</a>

        </li>     
        
        
 

    <li style="float:right;">
<a style="color:white;display:inline-block;font-weight:bold;
text-decoration:none;font-size:19px;" href="javascript:void(0);" id="upp" onclick="gg()">
    <span style="font-size:10px;color:white;margin-right:4px;" id="dd">Move to Top</span>&uArr;</a>

  </li>     
        

<script>



       $('#upp').click(function(){
           
           
                   $('html,body').animate({scrollTop:0},600);

           
       })

  




</script>
<script>




        

    </script>



    </ul>
    
    <style>
        
        ul.ul-list li a{
            
            text-decoration:none;
            


        }
        
       .footer ul.ul-list li a{
            font-size:12px;

        }
        
        
    </style>
    
    
    </nav>