<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>About US - NaijaRamz  </title>

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>

<div class="wrapper">
         
  <h1>Welcome to NaijaRamz</h1>
 <br> 
    <div class="main">
        
        
        
        
        
        <div class="section">
            
                  
       <h1 style="font-size:32px;">About us</h1>    
       
    <br>
      <center>  <img height="150px"  src="http://naijaramz.com/14763d33-d8f5-4a53-b4f8-10263d9de8b3_200x200.jpg" /></center>
      <br>  <br>
     <p class="p" style="font-size:16px;color:rgb(100,70,50);">

the people's site provide you with Science , Books ,Psychology ,History

,Sports
,Design
,Fashion and Style
,Economics
,Finance

,Education
,Healthy Eating

,Songs
,Nutrition
Entertainment
,Technology Trends
,Smartphones
,Recipes
Musicians and lots more
    			
</p>

    
    <p class="p" style="font-size:16px;color:rgb(100,70,50);">
        


Were dedicated in proving informations that helps you stay connected to the world 

Our Board members of trustees ensures that we deliver our mission and public purposes which are set out in the Charter. 
The Executive Committee is responsible for day-to-day management.. 

</p>

                  
                  
                  
        </div>
        
        
        
        
        
        
        <div class="section">
            
        
        
        
<h1><b>Introduction</b></h1>

<p class="p" style="font-size:16px;color:rgb(100,70,50);">
    
  With the name implies NAIJARAMZ literally means Nigeria as (Naija) and Ramsey as (Ramz) which means a strong island
combined together it means a strong nigeria that is how our name was derived from, as our name implies our website is strong and friendly
to all our users and subscribers.
    
    </p>
                  
        </div>
        
        
  
        <div class="section">
            
            <h1>Downloading Manager</h1>
              <center>  <img height="100px"  src="https://naijaramz.com/icons/dowm.jpg" /></center>
              
              
             <p  class="p" style="font-size:16px;color:rgb(100,70,50);">we also help you upload your favourite nollywood movies from youtube to our site </p>
    
            
            <p  class="p" style="font-size:16px;color:rgb(100,70,50);">to make them downloadable </p>
          
            
            
        </div>
              
        
        
        
        <div class="section">
            
               
<h1><b>Our goal</b></h1>
      <center>  <img height="150px"  src="http://naijaramz.com/icons/our-goal-png-1.png" /></center>
    <br>
 
<p  class="p" style="font-size:16px;color:rgb(100,70,50);">
  <br> is to take the pain out of providing news to the whole wide world, Our role is to fulfil our mission and promote our Public Purposes.
We offer services such as; News, sports, Entertainments, Comedy, Health, Gossips, Articles, Technologies and lots more....
Over the years we have carried out lots of researchs on how to improve the knowledge of the society, accelerate and to create awareness to the universe
so visit us today to get just what you have been looking for, Thank You...


</p>


                  
        </div>
        
        
        
        




</div>



<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>



<style>


p img{
    
    width:80%;
}



.wrapper{
    

    padding-left:1px;
    
}
    
    
    .p{
                margin-top:3px;
     font-family:monospace;
        
        
    }
    
    
    h1{
        
        text-indent:15px;
        
        @import url(//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization);
        
        
       text-shadow:0px 2px 3px gray;
       font-family:nasalization;
        @font-face {font-family: "Nasalization"; src: url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.eot"); src: url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.woff") format("woff"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.svg#Nasalization") format("svg"); }
]
    }
    
    
    
    
    .section{
        
        
        margin-top:19px;
        margin-bottom:39px;
        padding-top:9px; padding-bottom:9px;
        min-height:300px;
        box-shadow:0px 10px 10px 0px rgb(220,230,230);
        
    }
    
    
</style>

</body>

</html>