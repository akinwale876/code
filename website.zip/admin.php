<?php
session_start();

require 'connection.php';




if(isset($_POST['submit'])){
    
    
    
  $username = $_POST['email'];
    
   $password = $_POST['password'];
    
    $password = md5($password);

if($conn){
    

$sql = "SELECT * FROM author WHERE email='$username' AND password='$password' LIMIT 1";

$query = mysqli_query($conn,$sql);


if(mysqli_num_rows($query) > 0){
    
    
    $_SESSION['access'] = $password;
    
    
    header('location: welcome.php');


 
}else{
    
    
    echo 'authetication failed you entered incorrent details';
}


  
}
    
    
}




?>