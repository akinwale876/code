
<div class="footer" style="position:relative;">

<br>


  <div class="header-image" 
>  

</div>



    <nav><ul class="ul-list">

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/about" >About us</a>

        </li>
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/contact" >Contact Us</a>

        </li>
   
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/privacy-policy" >Privacy Policy</a>

        </li>     
        
        
 
<script>




        

    </script>



    </ul>


    
    <style>
        
        ul.ul-list li a{
            
            text-decoration:none;
            


        }
        
       .footer ul.ul-list li a{
            font-size:12px;

        }
        
        
    </style>
    
    
    </nav>
    
    


<style>
    
    p{
        font-size:11px;
        color:#07240f;
    }
</style>

<?php


include 'scroller.php';
   ?>


<div style="">
    <b style="color:rgb(90,90,100);margin-top:-40px;">Like us on facebook</b>
      <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FNaijaramz7&width=450&layout=standard&action=like&size=small&share=false&height=35&appId" width="450" height="35" style="border:none;overflow:hidden;display:inline-block;margin:10px;" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

    
</div>
</div>
</div>


<?php

/*
<div style="position:fixed;bottom:10px;left:10px;display:inline-block;z-index:1;background:rgb(240,240,240);padding:5px;display:none;width:97%;" class="container">
    
    <div style="position:relative;">

        
        <span style="background:rgb(200,200,200); border-radius:8px;position:absolute;right:4px;top:0;color:rgb(100,0,0);padding:5px;font-size:9px;font-weight:bold;cursor:pointer;" id="remove">Accept</span></div>
    
    <div style="overflow:auto;padding:8px;">
        
<center>

<p style="font-size:12px;  ">By continuing to browse or by clicking “Accept Cookies,” you agree to the storing of first- and third-party cookies on your device to enhance site navigation, analyze site usage, and assist in our marketing efforts. Read
 more at <a href="https://naijaramz.com/privacy-policy">policy</p>

</center> 


    </div>
    
</div>
*/

?>

    <p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;float: left;margin: 0;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>NaijaRamz</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved');

</script>

</small>
 



</p>



<a style="color:black;display:none;position:fixed;bottom:4px;right:6px;font-weight:bold;
text-decoration:none;font-size:19px;" href="javascript:void(0);" id="upp" onclick="gg()">
    <span style="font-size:10px;color:black;margin-right:4px;" id="dd">Move to Top</span>&uArr;</a>


<script>



       $('#upp').click(function(){
           
           
                   $('html,body').animate({scrollTop:0},600);

           
       })

  




</script>
<script>



    setInterval(function(){

          $('.main').fadeIn(1000);

 
        
    },1000);
   

var nnn;


nnn = 0;


    setInterval(function(){

if(nnn == 0){
            
           
          $('.container').fadeIn(2200);

          $('.imm').slideUp(500);
          $('.stories').fadeIn(500);
}
 
        
    },100);
   
    

    
    $('#remove').click(function(){
        

                    $('.container').fadeOut(1010);

    
    nnn = 1;    
    });
    
    
    
    $('#rem').click(function(){
        
            $('html').animate({opacity: '1'});
                    $('.container').animate({left:"0",top:"0"}, 'fast');

                    $('.container').slideUp(10);

    
    nnn = 1;    
    });
    
    

</script>











<script type="text/javascript">


var body = window;
 
 body.addEventListener('scroll', callMe);


   function callMe(){

       
if(document.documentElement.scrollTop > 400){
    
              $('#upp').fadeIn(1500);

}
  
if(document.documentElement.scrollTop < 400){
    
              $('#upp').fadeOut(1500);

}



   }


</script>



<script type="text/javascript">
  

         var imgs = document.getElementsByClassName('header-slide-img');


         for (var i = 0; i < imgs.length; i++) {
           var getwidth = imgs[i].width;
           
          // getwidth = getwidth - 90;
            //document.getElementById('mainslide').style.width = getwidth + 'px';
          // imgs[i].style.width = getwidth + 'px';


         }


         if (imgs.length == 0) {


                 document.getElementById('slideControl').style.display = 'none';
                 document.getElementById('slideControl1').style.display = 'none';
         }


</script>


