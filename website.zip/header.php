

<div class="header"  id="nav">

<?php 


include 'admin_init.php';



?>


<div class="left-header" style="position:relative;">
    
    
    

<a href="https://<?php echo $_SERVER['SERVER_NAME']?>"><div class="header-image" 
>  
</div>

</a>  

 


</div>




<label style="font-size:12px;position:absolute;top:5px;right:5px;">

   <i class="fa fa-clock"></i>

<span id="ttt"></span>

   <script>



setInterval(function(){



 date = new Date();

 var year = date.getFullYear();
 var months = date.getMonth();
 var day = date.getDay();

 var seconds = date.getSeconds();
 var minutes = date.getMinutes();
 var hours = date.getHours();


var realTime = hours + 'h : '+ minutes + 'm : '+ seconds + 's ';


document.getElementById('ttt').innerHTML = realTime;


},1000);



</script>

 </label>



<span  style="margin-right:20px;float:right;">
<span style="color:black;font-family:cursive;margin-top:-7px;font-size:11px;inline-height:28px;">
	
Connect with Us</span>
<a target="blank" href="https://www.facebook.com/naijaramz"><img style="height:17px;width:17px;margin-left:5px;" src="https://naijaramz.com/icons/facebook.png"  /></a>

<a target="blank" href="https://www.twitter.com/naija_ramz"><img style="height:17px;width:17px;margin-left:5px;" src="https://naijaramz.com/icons/twitter.png
"  /></a>
<a target="blank"  href="https://www.instagram.com/naijaramz"><img style="height:17px;width:17px;margin-left:5px;" src="https://naijaramz.com/icons/instagram.png
" /></a>
</span>

<br>

<br>




    <nav style="box-shadow: none;outline: none;" ><ul class="ul-list" id="nn">


    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>" title="updates and latest post" style="position:relative;text-indent:10px;font-weight:100;">Home

        </a>

        </li>
         

    <li style="position:relative;color:rgb(20,120,50);font-weight:100;">

        
  
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/howto.php" style="display: block;font-weight:100;">
        How to</a>
       
  

        </li>

        
    <li>
              <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Music" style="display: block;font-weight:100;">Music</a>

        
    </li>
    
      
    <li>

      
       
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Entertainment" style="display: block;font-weight:100;">  Entertainment</a>
      


        </li>
       
        
   <!-- <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/News" title="latest news informations" style="position:relative;text-indent:10px;font-weight:100;">News</a>

        
    </li>
 
    
 <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Sport" title="businesw" style="position:relative;text-indent:10px;font-weight:100;">Sports</a>

        
    </li>   -->
 



   

        </li>
        
      

  
 <!--   <li>
  <li>

<a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/forum.php" style="position:relative;text-indent:10px;font-weight:100;"
title="Ask question" >Gists Zone
        
        
        
        </a>

 </li>-->

 <!--   <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/articles.php" style="position:relative;text-indent:10px;font-weight:100;">
       Articles</a>
</li>

-->


<li>
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/comedy.php" style="display: block;font-weight:100;">Comedy</a>

</li>

<li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/movie.php" style="display: block;font-weight:100;">Yoruba Movies</a>

</li>
<li>
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Emovie.php" style="display: block;font-weight:100;">English  Movies</a>

</li>




 <!--   <li>

    <li class="dropdown" style="position:relative;color:rgb(20,120,50);font-weight:100;">
 Movies &#9774;
        
        
       <span class="sit" id="dropdown-content">
  
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Emovie.php" style="display: block;font-weight:100;">English  Movies</a>
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Hmovie.php" style="display: block;font-weight:100;">Hollywood  Movies</a>
       

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/movie.php" style="display: block;font-weight:100;">Yoruba Movies</a>



     </span>
        
  

        </li>
        -->
      


    


    <li>

        <a id="menu" class="menu" href="javascript:void(0);">
       &#9776;</a>
</li>
   



    </ul>


<script type="text/javascript">
	

var xN = 0;

$(document).ready(function(){


var ul = $('#nn');






$('#menu').click(function(){

           if(xN == 0){
xN = 1;
		   ul.css('height', 'auto')
		}else{
			xN = 0;
			ul.css('height', '35px')
		}


})


})

</script>



</nav>










    </div>