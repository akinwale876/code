<?php
require 'connection.php';


if (isset($_GET['url'])){

$url = $_GET['url'];


$url = explode('/',$url);


$url = end($url);


$mov_q = mysqli_query($conn,"SELECT * FROM movies WHERE `cleanurl` ='$url'");

if(mysqli_num_rows($mov_q) > 0){
    
    
    
    
    
    $post_query = mysqli_query($conn,"SELECT * FROM movies WHERE `cleanurl` ='$url'");

}

$post_q = mysqli_query($conn,"SELECT * FROM posts WHERE `cleanurl` ='$url'");

if(mysqli_num_rows($post_q) > 0){
$post_query = mysqli_query($conn,"SELECT * FROM posts WHERE `cleanurl` ='$url'");

}else{
    
    $url = explode('-', $url);
    $url = $url[0];
    
    echo'<script>
       
       window.location = "/search_server.php?q='.$url.'";
    
    </script>';
}





$data = mysqli_fetch_array($post_query);


$title = $data['title'];
$id = $data['id'];

$tag = $data['tag'];

$author = $data['author'];


$description= $data['description'];

$image = $data['picture_url'];

$cleanurl = $data['cleanurl'];

$content = $data['content'];
$category = $data['category'];

$views = $data['views'];
$comments = $data['comments'];
$comment_id = $data['comment_id'];

$likes = $data['likes'];

$date = $data['date'];





}


?>


