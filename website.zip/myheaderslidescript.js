
function __(el){

	return document.getElementsByClassName(el);
}



var slideheaderElements = __('header-slide-post');

slideheaderElements[0].style.display= 'block';


headercount = 1;

function headerslide(num) {
	



headercount += num;




if(headercount > slideheaderElements.length){

	headercount = 1;
}




for (var i = 0; i < slideheaderElements.length; i++) {
	slideheaderElements[i].style.display = 'none';
}






slideheaderElements[headercount - 1].style.display= 'block';

slideheaderElements[(headercount +1) - 1].style.display= 'block';
slideheaderElements[(headercount +2) - 1].style.display= 'block';


}


setInterval(function(){headerslide(1)},6200);












