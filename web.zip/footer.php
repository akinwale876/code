

<div class="footer"  style="background:none;">




<p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>Online Escrow</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved');

</script>

</small>
 
</p>
<style>
    
    p{
        font-size:11px;
        color:#07240f;
    }
</style>




</div>






<style>
    
    
    .sit::after{
        
        content:"";
        position:absolute;
        top:100%;
        left:30%;
        border-width:4px;
        border-color:rgb(200,40,40) transparent  transparent  transparent ;
        border-style:solid;
        
    }
    
</style>



